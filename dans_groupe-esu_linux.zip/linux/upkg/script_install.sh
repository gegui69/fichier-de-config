#!/bin/bash
sudo apt-get remove htop -y
exit