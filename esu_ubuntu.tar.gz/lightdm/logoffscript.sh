sleep 2 umount -f /tmp/netlogon \ 
umount -f $HOME
killall cntlm
