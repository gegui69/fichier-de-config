#!/bin/bash
while true; do
LINE=$(nc -l 10000)
echo $LINE
notify-send $LINE
echo "Message received"
done
