#!/bin/bash

sudo apt-get update
sudo apt-get full-upgrade -y ;
